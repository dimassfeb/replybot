package com.dicoding.katoumegumi;

public class Source {
    public String userId;
    public String groupId;
    public String roomId;
    public String type;
}
