package com.dicoding.katoumegumi;

public class Payload {
    public Events[] events;
}
