package com.dicoding.katoumegumi;

public class Message {
    public String type;
    public String id;
    public String text;
}
